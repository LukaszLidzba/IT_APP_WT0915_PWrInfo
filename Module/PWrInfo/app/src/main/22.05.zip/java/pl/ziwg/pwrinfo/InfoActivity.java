package pl.ziwg.pwrinfo;

import android.os.Bundle;

public class InfoActivity extends OwnActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.info_activity);
    }
}
